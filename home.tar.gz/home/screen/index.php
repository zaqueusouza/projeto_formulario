<?php
	  ini_set('display_errors',1);
	  ini_set('display_startup_erros',1);
	  error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
<form action="../php/web_controller.php" method="post">
	<article class="article">
		<header class="header logo">
			<!--<a href="#">Logo</a>-->			
			<img style="border-radius: 60px;" src="../imagens/icone-pet.jpg" width="70" height="70">
		</header>
		<nav class="menu">
			<ul>
				<li>				
					<div class="img3" style="margin-top: 9px;">
					<a href="">
						<img src="../imagens/icone-house4.png">										
					</a>	
					</div>
				</li>
				<li>
					<a href="">
						<img src="../imagens/icons8-documento.gif" width="50" height="50" class="img2">
					</a>
				</li>
				<li>
					<a href="">
						<img src="../imagens/seta-para-baixo.png" width="50" height="50" class="img2">
					</a>	
				</li>
			</ul>
		</nav>
	</article>
	<section class="section1">
		<strong><i>DESENVOLVIDO PELO ACE: ZAQUEU SILVA</i></strong>
		<div class="assunto">			
			<label style="color:red; font-size: 2em;">*</label>
			<input class="inputDadosPessoais seletor" type="text" placeholder="Assunto:" name="assunto">									
			<input type="date" name="data" style="width: 120px; height: 35px; border-radius: 5px; border-style: none; margin-left: 50px;">
		</div>
		<div class="">
			<label style="color:red; font-size: 2em;">*</label>
			<input class="inputDadosPessoais seletor" type="text" placeholder="Nome:" name="nome">			
		</div>
		<div>
			<label class="" style="color:red; font-size: 2em;">*</label>
			<input class="inputDadosPessoais seletor" type="text" placeholder="Rua:" name="rua">
			<label  style="color:red; font-size: 2em;">*</label>
			<input class="seletor" type="text" placeholder="Número" id="numero" name="numero">
		</div>
		<div>
			<input class="complemento seletor" style="border-style: none;" type="text" placeholder="Complemento:" name="complemento">
		</div>
		<div>
			<label style="color:red; font-size: 2em;">*</label>
			<input class="inputDadosPessoais seletor" type="text" placeholder="Bairro:" name="bairro">
			<label><label style="color:red; font-size: 2em;">*</label>UF</label>
			<select id="select1" name="uf">
				<option value="AC">AC-Acre</option>
				<option value="AL">AL-Alagoas</option>
				<option value="AP">AP-Amapá</option>
				<option value="AM">AM-Amazonas</option>
				<option value="BA">BA-Bahia</option>
				<option value="CE">CE-Ceará</option>
				<option value="DF">DF-Distrito Federal</option>
				<option value="ES">ES-Esperitu Santos</option>
				<option value="GO">GO-Goiás</option>
				<option value="MA">MA-Maranhão</option>
				<option value="MT">MT-Mato Grosso</option>
				<option value="MS">MS-Mato Grosso do Sul</option>
				<option value="MG">MG-Mina Gerais</option>
				<option value="PA">PA-Pará</option>
				<option value="PB">PB-Paraíba</option>
				<option value="PR">PR-Paraná</option>
				<option value="PE">PE-Pernambuco</option>
				<option value="PI">PI-Piauí</option>
				<option value="RJ">RJ-Rio de Janeiro</option>
				<option value="RN">RN-Rio Grande do Norte</option>
				<option value="RS">RS-Rio Grande do Sul</option>
				<option value="RO">RO-Rondônia</option>
				<option value="RR">RR-Roraima</option>
				<option value="SC">SC-Santa Catarina</option>
				<option value="SP">SP-São Paulo</option>
				<option value="SE">SE-Sergipe</option>
				<option>TO-Tocantins</option>				
			</select>
		</div>
	</section>
	<section class="section2">	
		<div id="section_2">		
			<div style="padding-bottom: 15px;">
				<label style="color:red; font-size: 2em;">*</label>
				<span>TIPO DE OCORRÊNCIA</span>
			</div>
			<div>			
				<input type="checkbox" id="1" name="animal_1" value="Animal agressor">			
				<label for="1">Animal agressor</label>
			</div>
			<div>			
				<input type="checkbox" id="2" name="animal_2" value="Morcego">
				<label for="2">Morcego</label>
			</div>				
			<div>			
				<input type="checkbox" id="3" name="animal_3" value="Vacinação">
				<label for="3">Vacinação</label>
			</div>
			<div>			
				<input type="checkbox" id="4" name="animal_4" value="Teste">
				<label for="4">Teste</label>
			</div>
			<div>			
				<input type="checkbox" id="5" name="animal_5" value="Esporotricose">
				<label for="5">Esporotricose</label>
			</div>
			<div>			
				<input type="checkbox" id="6" name="animal_6" value="Caramujo">
				<label for="6">Caramujo</label>
			</div>
			<div>			
				<input type="checkbox" id="7" name="animal_7" value="Desratização">
				<label for="7">Desratização</label>
			</div>
			<div>
				<input type="checkbox" id="8" name="animal_8">
				<label for="8">Outros, específique<label style="color:red; font-size: 2em;">*</label></label>
				<input type="text" class="section_2Input">
			</div>
		</div>
	</section>
	<section class="section3">
		<div id="section3-1">
			<div style="padding-bottom: 15px;">
				<label style="color:red; font-size: 2em;">*</label>
				<span>TIPO DE ANIMAL</span>
			</div>
			<div>			
				<input type="checkbox" id="9" name="animal_9" value="Cão">
				<label for="9">Cão</label>
			</div>
			<div>			
				<input type="checkbox" id="10" name="animal_10" value="Gato">
				<label for="10">Gato</label>
			</div>
			<div>			
				<input type="checkbox" id="11" name="animal_11" value="Ave">
				<label for="11">Ave</label>
			</div>
			<div>			
				<input type="checkbox" id="12" name="animal_12" value="Morcego">
				<label for="12">Morcego</label>
			</div>
			<div>			
				<input type="checkbox" id="13" name="animal_13" value="Timbu">
				<label for="13">Timbu</label>
			</div>
			<div>			
				<input type="checkbox" id="14" name="animal_14" value="PNH">
				<label for="14">PNH</label>
			</div>
			
			<div>			
				<input type="checkbox" id="15" name="animal_15">
				<label for="15">Outros, especifique<label style="color:red; font-size: 2em;">*</label></label>
				<input type="text" for="15" class="section_2Input seletor" name="animal_15">
			</div>
		</div>
		<div id="section3-1-2">
			<div style="padding-bottom: 15px;">
				<label style="color:red; font-size: 2em;">*</label><label>Informe a quantidade de animais</label>
				<input class="seletor" id="numeroAnimal" type="text" name="quantidadeAnimal">
			</div>
			<div>
				<div style="padding-bottom: 10px;">
					<label style="color:red; font-size: 2em;">*</label>
					<span>Houve contato com o animal ?</span>
				</div>
				<div style="padding-bottom: 10px;">
					<input type="radio" id="16" name="contAnim" value="Sim">
					<label for="16">Sim</label>
								
					<input type="radio"  id="17" name="contAnim" value="Não">
					<label for="17">Não</label>			
				
					<input type="radio"  id="18" name="contAnim" value="Não se aplica">
					<label for="18">Não se aplica</label>
				</div>
			</div>
			<div style="padding-bottom: 15px;">
				<div style="padding-bottom: 10px;">
					<label style="color:red; font-size: 2em;">*</label>
					<span>Animal imunizado contra a raiva ?</span>
				</div>
				<div>					
					<input type="radio" id="19" name="animImuni" value="Sim">
					<label for="19">Sim</label>				
				
					<input type="radio"  id="20" name="animImuni" value="Não">
					<label for="20">Não</label>
				
					<input type="radio"" id="21" name="animImuni" value="Não se aplica"> 
					<label for="21">Não se aplica</label>
				</div>
			</div>
		</div>
	</section>	
	<section class="section4">
		<div id="section4-1">
			<div style="padding-bottom: 15px;">
				<label style="color:red; font-size: 2em;">*</label>
				<span>RELAÇÃO DO USUÁRIO COM O ANIMAL(pode marcar mais de uma opção)</span>
			</div>
			<div>			
				<input type="checkbox" id="relacao1" name="vitimaCao" value="Vítima de agressão por animal">
				<label for="relacao1">Vítima de agressão por animal</label>
			</div>
			<div>			
				<input type="checkbox" id="relacao2" name="contatoAnimal" value="Contato com o animal suspeito">
				<label for="relacao2">Contato com o animal suspeito</label>
			</div>
			<div>			
				<input type="checkbox" id="relacao3" name="tutor" value="Tutor">
				<label for="relacao3">Tutor</label>
			</div>
			<div>			
				<input type="checkbox" id="relacao4" name="parenteVitima" value="Parente da vítima">
				<label for="relacao4">Parente da vítima</label>
			</div>
			<div>			
				<input type="checkbox" id="relacao5" name="suspeitoInfixaoZoonoses" value="Suspeito de infecção por zoonoses"> 
				<label for="relacao5">Suspeito de infecção por zoonoses</label>
			</div>
			<div>			
				<input type="checkbox" id="relacao6" name="apenasInformante" value="Sou apenas o informante">
				<label for="relacao6">Sou apenas o informante</label>
			</div>				
	</section>
	
	<section class="section5">
		<div id="section5-1">
			<div>
				<label style="color:red; font-size: 2em;">*</label>
				<span style="color: whitesmoke; font-size: 1.4rem;">RSUMO DA OCORRÊNCIA</span>
			</div>			
			<textarea placeholder="Informe aqui o resumo da ocorrência:" rows="7" cols="70" type="textarea" id="resumocorrencia" name="resumOcorrencia"></textarea>	
		</div>	
	</section>	
	<section class="section6">
		<div id="section6-1">
			<div style="padding-bottom: 15px;">
				<label style="color:red; font-size: 2em;">*</label>
				<span>VIA DE RECEBIMENTO</span>
			</div>
			<div>			
				<input type="radio" id="22" name="viaRecebimento" value="Presencial">
				<label for="22">Presencial</label>
			</div>
			<div>			
				<input type="radio" id="23" name="viaRecebimento" value="E-mail">
				<label for="23">E-mail</label>
			</div>
			<div style="padding-bottom: 20px;">			
				<input type="radio" id="24" name="viaRecebimento" value="1 Doc">
				<label for="24">1 Doc</label>				
			</div>
			<div style="padding-bottom: 20px;">
				<input type="radio" id="241" name="viaRecebimento">
				<label for="241">especifique: </label>
				<input class="seletor" type="text" placeholder="Outros, especifique:" id="section6-2" name="viaRecebimento">
			</div>
			<div>
				<div style="padding-bottom: 10px;">
					<label style="color:red; font-size: 2em;">*</label>
					<span>Demanda encaminhada</span>
				</div>
				<div>				
					<input type="radio" id="25" name="demanEncaminad" value="Sim">			
					<label for="25">Sim</label>
				</div>
				<div style="padding-bottom: 15px;">				
					<input type="radio" id="26" name="demanEncaminad" value="Não">
					<label for="26">Não</label>
				</div>	
			</div>
		</div>	
	</section>	
	<section class="section7">
		<div id="section7-1" style="padding-bottom: 15px;">
			<div style="padding-bottom: 15px;">
				<label style="color:red; font-size: 2em;">*</label>			
				<span>NÚCLEO ENCAMINHADO</span>
			</div>	
			<div>
			<input type="checkbox" id="encaminhado1" name="recepcao" value="Educação">
				<label for="encaminhado1">Recepçaõ</label>
			</div>	
			<div>			
				<input type="checkbox" id="encaminhado2" name="educacao" value="Educação">
				<label for="encaminhado2">Educação</label>
			</div>
			<div>			
				<input type="checkbox" id="encaminhado3" name="sinantropico" value="Sinantrópicos">
				<label for="encaminhado3">Sinantrópicos</label>
			</div>
			<div>			
				<input type="checkbox" id="encaminhado4" name="leishmaniose" value="Leishmaniose">
				<label for="encaminhado4">Leishmaniose</label>
			</div>
		</div>	
	</section>
	<section class="section8">
		<div id="section8-1">
			<div style="padding-bottom: 15px;">
				<label style="color:red; font-size: 2em;">*</label>
				<span>RESPONSÁVEL PELO ATENDIMENTO</span>
			</div>
			<div>
				<input style="border-style: none; padding-top: 15px;" class="seletor" type="text" placeholder="Responsável pelo atendimento:" id="section8-2" name="responsvelPeloAtendimento" style="width: 300px;">				
			</div>
			<div style="margin-top: 20px;">
				<textarea style="border-style: none;" class="seletor" type="textarea" rows="4" cols="50" placeholder="Servidores designados:" name="servidoresDesignados"></textarea>
			</div>			
		</div>
					
		<div class="btn">
			<button class="btn_1" type="submit" name="enviar">
				<a href="#"><img src="../imagens/enviar.png"></a>
			</button>
		</div>		
	</section>			
</form>	
</body>
</html>