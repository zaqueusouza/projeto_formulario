<?php
/**
 * no momento só consigo enviar para o banco de dados apenas dois registro, mas 
 * toda vez que tento enviar mais de dois registro para o banco de dados a tela fica branca.
 * 
 */

$conexao = new PDO('mysql:host=localhost;dbname=zoonoses','root','');
$conexao->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
  
  if(isset($_POST['assunto'])){
       $sql=$conexao->prepare("INSERT INTO bt_registros VALUES (null,?,?)");
       $sql->execute(array($_POST['assunto'],$_POST['nome']));       
 }

?>        